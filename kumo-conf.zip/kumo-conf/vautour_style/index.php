<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>Web Interface Monitoring</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta http-equiv="Content-Language" content="en" />
	<meta name="robots" content="noindex, nofollow" />
	<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico" />
</head>
	<frameset rows="60,*" frameborder="0" framespacing="0">
		<frame src="top.html" name="top" />
		<frameset cols="200,*" frameborder="0" framespacing="0">
			<frame src="menu.html" name="side" target="main" noresize="noresize" />
			<frameset rows="26,*" frameborder="0" framespacing="0">
				<frame src="sidebar.html" name="navigation" noresize="noresize" />
				<frame src="cgi-bin/tac.cgi" name="main" noresize="noresize" />
			</frameset>
		</frameset>
		<noframes>
			<body>
				<p>These pages require a browser which supports frames.</p>
			</body>
		</noframes>
	</frameset>
</html>