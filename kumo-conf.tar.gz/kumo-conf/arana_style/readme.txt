Arana Theme Style


1. DESCRIPTION

Arana Theme Style is a skin for Nagios 3.X.
Original stylesheets and original icons have been modified to provide a different presentation for the Nagios web interface.


2. CREDITS

Arana Theme Style have been created by Eduardo L. Arana based on the theme by Yoann LAMY.
The menu of Arana Theme use the javascript framework MooTools (http://mootools.net/).
The icons of Arana Theme use "Silk icon set" (http://www.famfamfam.com/lab/icons/silk/) created by Mark James. "Silk icon set" is licensed under Creative Commons Attribution 2.5 License (http://creativecommons.org/licenses/by/2.5/).


3. INSTALL

Extract the contents of this ZIP file in the Nagios web content folder (usually /usr/local/nagios/share/) : unzip aranatheme.zip -d /usr/local/nagios/share/ 